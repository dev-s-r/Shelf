// Writes www/build-info.json (inside the app and the web bundle) and release-info.json (the release body).
// minApk = the build number of the last build that changed native code, so the app knows when a quick web update is enough.
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

const root = path.join(__dirname, '..');
const files = [];
const javaDir = path.join(root, 'android-src');
if (fs.existsSync(javaDir)) for (const f of fs.readdirSync(javaDir).sort()) if (f.endsWith('.java')) files.push(path.join(javaDir, f));
for (const f of ['scripts/prepare-android.js', 'package.json', 'capacitor.config.json']) files.push(path.join(root, f));

const h = crypto.createHash('sha256');
for (const f of files) h.update(fs.readFileSync(f));
const hash = h.digest('hex').slice(0, 12);

let prev = {};
try { prev = JSON.parse(process.env.PREV || '{}'); } catch (e) { /* no earlier release */ }
const build = +process.env.GITHUB_RUN_NUMBER || 1;
const minApk = (prev.nativeHash === hash && prev.minApk) ? prev.minApk : build;
const notes = (process.env.COMMIT_MSG || '').split('\n')[0].slice(0, 120);
const info = { build, nativeHash: hash, minApk, notes };

fs.mkdirSync(path.join(root, 'www'), { recursive: true });
fs.writeFileSync(path.join(root, 'www', 'build-info.json'), JSON.stringify(info));
fs.writeFileSync(path.join(root, 'release-info.json'), JSON.stringify(info));
console.log(info);

// Runs after `npx cap add android`: Java files, manifest permissions, launcher icons, splash, version.
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const root = path.join(__dirname, '..');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const pkg = cfg.appId;
const app = path.join(root, 'android', 'app');
const main = path.join(app, 'src', 'main');

/* ---- MainActivity ---- */
const javaDir = path.join(main, 'java', ...pkg.split('.'));
fs.mkdirSync(javaDir, { recursive: true });
for (const f of fs.readdirSync(path.join(root, 'android-src')).filter(n => n.endsWith('.java'))) {
  const tpl = fs.readFileSync(path.join(root, 'android-src', f), 'utf8');
  fs.writeFileSync(path.join(javaDir, f), tpl.replace(/__PACKAGE__/g, pkg));
}

/* ---- widget resources (layouts, drawables, widget configs) ---- */
function copyDir(from, to) {
  if (!fs.existsSync(from)) return;
  fs.mkdirSync(to, { recursive: true });
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}
copyDir(path.join(root, 'android-src', 'res'), path.join(main, 'res'));

/* ---- AndroidManifest: permissions for in-app updates and saving to Downloads ---- */
const manPath = path.join(main, 'AndroidManifest.xml');
let man = fs.readFileSync(manPath, 'utf8');
if (!man.includes('REQUEST_INSTALL_PACKAGES')) {
  man = man.replace('</manifest>',
    '    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n    <uses-permission android:name="android.permission.UPDATE_PACKAGES_WITHOUT_USER_ACTION" />\n</manifest>');
}
if (!man.includes('WRITE_EXTERNAL_STORAGE')) {
  man = man.replace('</manifest>',
    '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n</manifest>');
}
if (!man.includes('barcode_ui')) {
  // Ask Google Play services to download the barcode scanner module when the app is installed.
  man = man.replace('</application>',
    '    <meta-data android:name="com.google.mlkit.vision.DEPENDENCIES" android:value="barcode_ui" />\n    </application>');
}
if (!man.includes('ReminderReceiver')) {
  man = man.replace('</manifest>',
    '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n</manifest>');
  man = man.replace('</application>',
    '    <receiver android:name=".ReminderReceiver" android:exported="true">\n            <intent-filter>\n                <action android:name="android.intent.action.BOOT_COMPLETED" />\n                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />\n            </intent-filter>\n        </receiver>\n    </application>');
}
if (!man.includes('ReadingWidget')) {
  const w = (cls, xml) => '    <receiver android:name=".' + cls + '" android:exported="true">\n            <intent-filter>\n                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />\n            </intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/' + xml + '" />\n        </receiver>\n';
  man = man.replace('</application>', [['StreakWidget','streak'],['TodayWidget','today'],['ReadingWidget','reading'],['NextWidget','next'],['FocusWidget','focus'],['YearWidget','year'],['WeekWidget','week'],['AddWidget','add']].map(x => w(x[0], 'widget_' + x[1] + '_info')).join('') + '    </application>');
}
fs.writeFileSync(manPath, man);

/* ---- version ---- */
const gradlePath = path.join(app, 'build.gradle');
let gradle = fs.readFileSync(gradlePath, 'utf8');
const code = process.env.VERSION_CODE || '1';
const name = process.env.VERSION_NAME || '1.0.0';
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${code}`).replace(/versionName\s+"[^"]*"/, `versionName "${name}"`);
gradle += `
dependencies {
    implementation 'com.google.android.gms:play-services-code-scanner:16.1.0'
}
android {
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
`;
fs.writeFileSync(gradlePath, gradle);

/* ---- notification icon ---- */
fs.mkdirSync(path.join(main, 'res', 'drawable'), { recursive: true });
fs.writeFileSync(path.join(main, 'res', 'drawable', 'ic_stat_shelf.xml'),
  '<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n    <path android:fillColor="#FFFFFF" android:pathData="M4,4h4v14h-4z M9.5,7h4v11h-4z M15,6.5l3.6,-0.8l2.4,11.8l-3.6,0.8z M3,19.5h18v2h-18z"/>\n</vector>\n');

/* ---- launcher icons from icon-512.png ---- */
(async () => {
  const srcIcon = path.join(root, 'web', 'icon-512.png');
  const { data } = await sharp(srcIcon).raw().toBuffer({ resolveWithObject: true });
  const bg = '#' + [data[0], data[1], data[2]].map(v => v.toString(16).padStart(2, '0')).join('');

  const res = path.join(main, 'res');
  const legacy = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
  const adaptive = { mdpi: 108, hdpi: 162, xhdpi: 216, xxhdpi: 324, xxxhdpi: 432 };

  for (const d of Object.keys(legacy)) {
    const dir = path.join(res, `mipmap-${d}`);
    fs.mkdirSync(dir, { recursive: true });
    const s = legacy[d];
    const square = await sharp(srcIcon).resize(s, s).png().toBuffer();
    fs.writeFileSync(path.join(dir, 'ic_launcher.png'), square);
    const mask = Buffer.from(`<svg width="${s}" height="${s}"><circle cx="${s / 2}" cy="${s / 2}" r="${s / 2}"/></svg>`);
    await sharp(square).composite([{ input: mask, blend: 'dest-in' }]).png().toFile(path.join(dir, 'ic_launcher_round.png'));

    // adaptive foreground: icon in the centre 68% (safe zone), transparent elsewhere
    const a = adaptive[d];
    const inner = Math.round(a * 0.68);
    const fg = await sharp(srcIcon).resize(inner, inner).png().toBuffer();
    await sharp({ create: { width: a, height: a, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
      .composite([{ input: fg, gravity: 'center' }]).png()
      .toFile(path.join(dir, 'ic_launcher_foreground.png'));
  }

  // splash screens: brand colour with the icon centred (portrait + landscape)
  const port = { mdpi: [320, 480], hdpi: [480, 800], xhdpi: [720, 1280], xxhdpi: [960, 1600], xxxhdpi: [1280, 1920] };
  async function splash(w, h) {
    const size = Math.round(Math.min(w, h) * 0.34);
    const logo = await sharp(srcIcon).resize(size, size).png().toBuffer();
    return sharp({ create: { width: w, height: h, channels: 4, background: bg } })
      .composite([{ input: logo, gravity: 'center' }]).png().toBuffer();
  }
  for (const d of Object.keys(port)) {
    const [w, h] = port[d];
    for (const [folder, W, H] of [[`drawable-port-${d}`, w, h], [`drawable-land-${d}`, h, w]]) {
      fs.mkdirSync(path.join(res, folder), { recursive: true });
      fs.writeFileSync(path.join(res, folder, 'splash.png'), await splash(W, H));
    }
  }
  fs.mkdirSync(path.join(res, 'drawable'), { recursive: true });
  fs.writeFileSync(path.join(res, 'drawable', 'splash.png'), await splash(480, 800));

  // Android 12+ splash background colour
  const stylesPath = path.join(res, 'values', 'styles.xml');
  if (fs.existsSync(stylesPath)) {
    let st = fs.readFileSync(stylesPath, 'utf8');
    if (!st.includes('windowSplashScreenBackground') && /name="AppTheme\.NoActionBarLaunch"[^>]*>/.test(st)) {
      st = st.replace(/(name="AppTheme\.NoActionBarLaunch"[^>]*>)/,
        '$1\n        <item name="windowSplashScreenBackground">@color/ic_launcher_background</item>');
      fs.writeFileSync(stylesPath, st);
    }
  }

  // remove template vector icons so they don't clash with ours
  for (const p of ['drawable/ic_launcher_background.xml', 'drawable-v24/ic_launcher_foreground.xml']) {
    fs.rmSync(path.join(res, p), { force: true });
  }
  fs.mkdirSync(path.join(res, 'values'), { recursive: true });
  fs.writeFileSync(path.join(res, 'values', 'ic_launcher_background.xml'),
    `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${bg}</color>\n</resources>\n`);

  const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
  const any = path.join(res, 'mipmap-anydpi-v26');
  fs.mkdirSync(any, { recursive: true });
  fs.writeFileSync(path.join(any, 'ic_launcher.xml'), adaptiveXml);
  fs.writeFileSync(path.join(any, 'ic_launcher_round.xml'), adaptiveXml);
  console.log('Android project prepared (icon background ' + bg + ')');
})().catch(e => { console.error(e); process.exit(1); });

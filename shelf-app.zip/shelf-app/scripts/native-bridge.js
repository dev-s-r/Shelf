/* Connects the web app to Android: saving downloads, back gesture, system bar colours. */
(function () {
  'use strict';
  function native() { return window.AndroidBridge; }

  /* ---- saving: small files in one go, big files in pieces ---- */
  function toB64(blob) {
    return new Promise(function (res, rej) {
      var rd = new FileReader();
      rd.onload = function () { res(String(rd.result).split(',')[1] || ''); };
      rd.onerror = function () { rej(rd.error); };
      rd.readAsDataURL(blob);
    });
  }
  async function saveBlob(name, blob, quiet) {
    var B = native();
    var type = blob.type || 'application/octet-stream';
    if (blob.size <= 3 * 1024 * 1024 || !B.saveBegin) {
      var data = await toB64(blob);
      return quiet ? B.saveFileQuiet(name, type, data) : B.saveFile(name, type, data);
    }
    var id = B.saveBegin(name, type);
    if (!id) { if (!quiet) B.saveFile(name, type, ''); return false; }
    var CH = 1536 * 1024; // multiple of 3, so every piece is valid base64 on its own
    for (var off = 0; off < blob.size; off += CH) {
      var ok = B.saveChunk(id, await toB64(blob.slice(off, off + CH)));
      if (!ok) { B.saveEnd(id, false); return false; }
    }
    return B.saveEnd(id, !quiet);
  }
  window.__nativeSaveBlob = saveBlob;

  /* ---- downloads: blob links -> Downloads folder ---- */
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest && ev.target.closest('a[download]');
    if (!a || !/^blob:/.test(a.href) || !native()) return;
    ev.preventDefault();
    ev.stopPropagation();
    var name = a.getAttribute('download') || 'file';
    fetch(a.href).then(function (r) { return r.blob(); }).then(function (blob) {
      return saveBlob(name, blob, false);
    });
  }, true);

  /* ---- back gesture: the web app can define window.__appBack() to close its own dialogs/menus.
          Return true from it when something was closed; otherwise the back gesture leaves the app. ---- */
  window.__nativeBack = function () {
    try { return typeof window.__appBack === 'function' ? !!window.__appBack() : false; } catch (e) { return false; }
  };

  /* ---- status / navigation bar colours follow the app theme ---- */
  function syncChrome() {
    var B = native();
    if (!B || !B.setChrome || !document.body) return;
    var m = getComputedStyle(document.body).backgroundColor.match(/\d+/g);
    if (!m || m.length < 3) return;
    var hex = '#' + m.slice(0, 3).map(function (x) { return ('0' + (+x).toString(16)).slice(-2); }).join('');
    B.setChrome(hex, (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) < 128);
  }
  document.addEventListener('DOMContentLoaded', function () {
    syncChrome();
    var mo = new MutationObserver(syncChrome);
    mo.observe(document.documentElement, { attributes: true });
    mo.observe(document.body, { attributes: true });
    if (window.matchMedia) window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { setTimeout(syncChrome, 50); });
  });
  window.addEventListener('load', function () { setTimeout(syncChrome, 300); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) syncChrome(); });
})();

// Copies the web app from /web into /www and adds the two helper scripts (native bridge + updater).
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const src = path.join(root, 'web');
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

// The browser service worker is not needed inside the app (it could also serve stale files after an update).
for (const f of fs.readdirSync(src)) {
  if (f === 'sw.js') continue;
  fs.cpSync(path.join(src, f), path.join(out, f), { recursive: true });
}
fs.copyFileSync(path.join(root, 'scripts', 'native-bridge.js'), path.join(out, 'native-bridge.js'));

const file = path.join(out, 'index.html');
if (!fs.existsSync(file)) throw new Error('web/index.html not found - the app needs an index.html');
let html = fs.readFileSync(file, 'utf8');

// native bridge goes first in <head>
if (!html.includes('native-bridge.js')) {
  if (/<head[^>]*>/i.test(html)) html = html.replace(/<head[^>]*>/i, m => m + '\n<script src="native-bridge.js"></script>');
  else html = '<script src="native-bridge.js"></script>\n' + html;
}
// the updater goes at the end of <body> (before the LAST </body>, so a "</body>" inside a script string is safe)
if (fs.existsSync(path.join(out, 'app-update.js')) && !html.includes('app-update.js')) {
  const i = html.toLowerCase().lastIndexOf('</body>');
  const tag = '<script src="app-update.js"></script>\n';
  html = i >= 0 ? html.slice(0, i) + tag + html.slice(i) : html + '\n' + tag;
}
fs.writeFileSync(file, html);
console.log('www/ ready');

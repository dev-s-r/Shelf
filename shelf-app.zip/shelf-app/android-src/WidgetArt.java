package __PACKAGE__;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

/* Draws every home-screen widget as one picture, sized exactly to the widget. */
final class WidgetArt {
  static final int INK = 0xFF14161F, PANEL = 0xFF1E2130, WHITE = 0xFFFFFFFF, SLATE = 0xFF4A4F6A, PAPER = 0xFFE8E6DF;
  static final Typeface MED = Typeface.create("sans-serif-medium", Typeface.NORMAL);
  static final Typeface BOLD = Typeface.create("sans-serif", Typeface.BOLD);
  static final Typeface BLK = Typeface.create("sans-serif-black", Typeface.NORMAL);

  static final class Zone {
    final RectF r;
    final String act;
    Zone(RectF r, String act) { this.r = r; this.act = act; }
  }

  static final class Out {
    Bitmap bmp;
    float scale = 1f;
    final ArrayList<Zone> zones = new ArrayList<>();
    String desc = "";
    String tap = "lib";
    boolean chron, down;
    long ms;
    RectF chronBox = new RectF();
    float chronPx;
    int chronColor = INK;
  }

  private WidgetArt() {}

  static Out paint(Context ctx, String kind, JSONObject d, float wDp, float hDp, float dens) {
    float s = 1f;
    int W = Math.max(40, Math.round(wDp * dens)), H = Math.max(40, Math.round(hDp * dens));
    float cap = 3500000f;
    if (W * (float) H * 4f > cap) {
      s = (float) Math.sqrt(cap / (W * (float) H * 4f));
      W = Math.round(W * s);
      H = Math.round(H * s);
    }
    Bitmap b = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    Out out = new Out();
    out.bmp = b;
    out.scale = s;
    Art a = new Art(ctx, new Canvas(b), W, H, dens * s, d, out);
    switch (kind) {
      case "streak": a.streak(); break;
      case "today": a.today(); break;
      case "reading": a.reading(); break;
      case "next": a.next(); break;
      case "focus": a.focus(); break;
      case "year": a.year(); break;
      case "week": a.week(); break;
      default: a.add(); break;
    }
    return out;
  }

  static final class Art {
    final Context ctx;
    final Canvas cv;
    final int W, H;
    final float dp;
    final JSONObject d;
    final Out out;
    final boolean dk;
    final int acc, card, tile, fg;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF rf = new RectF();
    float u = 1f;

    Art(Context ctx, Canvas cv, int W, int H, float dp, JSONObject d, Out out) {
      this.ctx = ctx; this.cv = cv; this.W = W; this.H = H; this.dp = dp; this.d = d; this.out = out;
      dk = d.optBoolean("dk", false);
      acc = parse(d.optString("acc", "#D4F53C"));
      card = dk ? PANEL : WHITE;
      tile = dk ? 0xFF2A2E40 : PAPER;
      fg = dk ? WHITE : INK;
    }

    /* ---------- colour and text helpers ---------- */
    static int parse(String s) {
      try { return Color.parseColor(s); } catch (Exception e) { return 0xFFD4F53C; }
    }
    static int al(int c, float a) { return (c & 0x00FFFFFF) | (Math.round(255 * a) << 24); }
    static int mix(int x, int y, float t) {
      return Color.rgb(Math.round(Color.red(x) * t + Color.red(y) * (1 - t)),
          Math.round(Color.green(x) * t + Color.green(y) * (1 - t)),
          Math.round(Color.blue(x) * t + Color.blue(y) * (1 - t)));
    }
    int acd() { return dk ? acc : mix(acc, INK, 0.5f); }
    float fs(float k, float minDp) { return Math.max(minDp * dp, k * u); }
    float rad() { return Math.max(16 * dp, Math.min(17 * u, 30 * dp)); }
    void bg(int col) { rr(0, 0, W, H, rad(), col); }

    void rr(float l, float t, float r, float b, float rad, int col) {
      p.setStyle(Paint.Style.FILL); p.setColor(col); rf.set(l, t, r, b);
      cv.drawRoundRect(rf, rad, rad, p);
    }
    void rrs(float l, float t, float r, float b, float rad, int col, float sw) {
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(col);
      rf.set(l + sw / 2, t + sw / 2, r - sw / 2, b - sw / 2);
      cv.drawRoundRect(rf, rad, rad, p);
      p.setStyle(Paint.Style.FILL);
    }
    void face(float size, int style) {
      p.setStyle(Paint.Style.FILL);
      p.setTypeface(style == 2 ? BLK : style == 1 ? BOLD : MED);
      p.setTextSize(size);
    }
    float tw(String s, float size, int style) { face(size, style); return p.measureText(s); }
    String fit(String s, float size, int style, float maxW) {
      if (s == null) return "";
      if (maxW <= 0) return "";
      if (tw(s, size, style) <= maxW) return s;
      String t = s;
      while (t.length() > 1 && tw(t + "\u2026", size, style) > maxW) t = t.substring(0, t.length() - 1);
      return t.trim() + "\u2026";
    }
    /* Draws text; the baseline is at y. align: 0 left, 1 centre, 2 right. */
    void text(String s, float x, float y, float size, int col, int style, int align, float maxW) {
      String t = maxW > 0 ? fit(s, size, style, maxW) : s;
      face(size, style);
      p.setColor(col);
      p.setTextAlign(align == 1 ? Paint.Align.CENTER : align == 2 ? Paint.Align.RIGHT : Paint.Align.LEFT);
      cv.drawText(t, x, y, p);
      p.setTextAlign(Paint.Align.LEFT);
    }
    float cbase(float cy, float size, int style) { face(size, style); return cy - (p.ascent() + p.descent()) / 2f; }
    /* Draws text so its bottom edge is at 'bottom'; returns its top edge. */
    float stack(String s, float x, float bottom, float size, int col, int style, int align, float maxW) {
      face(size, style);
      float base = bottom - p.descent();
      float top = base + p.ascent();
      text(s, x, base, size, col, style, align, maxW);
      return top;
    }
    ArrayList<String> wrap(String s, float size, int style, float maxW, int maxLines) {
      ArrayList<String> lines = new ArrayList<>();
      String[] words = (s == null ? "" : s).split("\\s+");
      String cur = "";
      for (int i = 0; i < words.length; i++) {
        String t = cur.isEmpty() ? words[i] : cur + " " + words[i];
        if (tw(t, size, style) <= maxW || cur.isEmpty()) { cur = t; continue; }
        lines.add(cur);
        cur = words[i];
        if (lines.size() == maxLines - 1) {
          StringBuilder rest = new StringBuilder(cur);
          for (int j = i + 1; j < words.length; j++) rest.append(' ').append(words[j]);
          cur = rest.toString();
          break;
        }
      }
      if (!cur.isEmpty()) lines.add(fit(cur, size, style, maxW));
      return lines;
    }

    /* ---------- shapes and icons ---------- */
    void ring(float cx, float cy, float r, float sw, int track, int col, float prog) {
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setColor(track);
      cv.drawCircle(cx, cy, r, p);
      if (prog > 0f) {
        p.setColor(col); p.setStrokeCap(Paint.Cap.ROUND);
        rf.set(cx - r, cy - r, cx + r, cy + r);
        cv.drawArc(rf, -90f, 360f * Math.min(1f, prog), false, p);
        p.setStrokeCap(Paint.Cap.BUTT);
      }
      p.setStyle(Paint.Style.FILL);
    }
    void icon(String k, float cx, float cy, float s, int col) {
      p.setColor(col);
      p.setStrokeWidth(Math.max(1.6f * dp, s * 0.12f));
      p.setStrokeCap(Paint.Cap.ROUND);
      Path path = new Path();
      switch (k) {
        case "play":
          p.setStyle(Paint.Style.FILL);
          path.moveTo(cx - 0.28f * s, cy - 0.42f * s); path.lineTo(cx + 0.42f * s, cy); path.lineTo(cx - 0.28f * s, cy + 0.42f * s); path.close();
          cv.drawPath(path, p); break;
        case "pause":
          p.setStyle(Paint.Style.FILL);
          cv.drawRect(cx - 0.3f * s, cy - 0.38f * s, cx - 0.1f * s, cy + 0.38f * s, p);
          cv.drawRect(cx + 0.1f * s, cy - 0.38f * s, cx + 0.3f * s, cy + 0.38f * s, p); break;
        case "plus":
          p.setStyle(Paint.Style.STROKE);
          cv.drawLine(cx, cy - 0.4f * s, cx, cy + 0.4f * s, p); cv.drawLine(cx - 0.4f * s, cy, cx + 0.4f * s, cy, p); break;
        case "fire":
          p.setStyle(Paint.Style.FILL);
          path.moveTo(cx, cy - 0.5f * s);
          path.cubicTo(cx + 0.1f * s, cy - 0.2f * s, cx + 0.4f * s, cy - 0.1f * s, cx + 0.4f * s, cy + 0.15f * s);
          path.cubicTo(cx + 0.4f * s, cy + 0.4f * s, cx + 0.2f * s, cy + 0.5f * s, cx, cy + 0.5f * s);
          path.cubicTo(cx - 0.2f * s, cy + 0.5f * s, cx - 0.4f * s, cy + 0.4f * s, cx - 0.4f * s, cy + 0.15f * s);
          path.cubicTo(cx - 0.4f * s, cy - 0.1f * s, cx - 0.15f * s, cy - 0.2f * s, cx, cy - 0.5f * s);
          path.close(); cv.drawPath(path, p); break;
        case "flag":
          p.setStyle(Paint.Style.STROKE);
          cv.drawLine(cx - 0.3f * s, cy - 0.45f * s, cx - 0.3f * s, cy + 0.5f * s, p);
          p.setStyle(Paint.Style.FILL);
          path.moveTo(cx - 0.3f * s, cy - 0.45f * s); path.lineTo(cx + 0.4f * s, cy - 0.25f * s); path.lineTo(cx - 0.3f * s, cy - 0.02f * s); path.close();
          cv.drawPath(path, p); break;
        case "swap":
          p.setStyle(Paint.Style.STROKE);
          cv.drawLine(cx - 0.4f * s, cy - 0.2f * s, cx + 0.4f * s, cy - 0.2f * s, p);
          cv.drawLine(cx + 0.4f * s, cy - 0.2f * s, cx + 0.2f * s, cy - 0.38f * s, p);
          cv.drawLine(cx + 0.4f * s, cy + 0.2f * s, cx - 0.4f * s, cy + 0.2f * s, p);
          cv.drawLine(cx - 0.4f * s, cy + 0.2f * s, cx - 0.2f * s, cy + 0.38f * s, p); break;
        case "reset":
          p.setStyle(Paint.Style.STROKE);
          rf.set(cx - 0.36f * s, cy - 0.36f * s, cx + 0.36f * s, cy + 0.36f * s);
          cv.drawArc(rf, 30f, 290f, false, p);
          cv.drawLine(cx + 0.31f * s, cy - 0.2f * s, cx + 0.38f * s, cy - 0.42f * s, p);
          cv.drawLine(cx + 0.31f * s, cy - 0.2f * s, cx + 0.1f * s, cy - 0.24f * s, p); break;
        default: break;
      }
      p.setStyle(Paint.Style.FILL);
      p.setStrokeCap(Paint.Cap.BUTT);
    }

    /* A pill button. ghost = outline only. Registers a tap zone when act is not null. */
    void pill(float l, float t, float r, float b, String label, int bgc, int fgc, boolean ghost, float size, String act) {
      float rad = (b - t) / 2f;
      if (ghost) rrs(l, t, r, b, rad, fgc, Math.max(1.5f * dp, 1.5f));
      else rr(l, t, r, b, rad, bgc);
      text(label, (l + r) / 2f, cbase((t + b) / 2f, size, 1), size, fgc, 1, 1, r - l - 8 * dp);
      if (act != null) out.zones.add(new Zone(new RectF(l, t, r, b), act));
    }
    void round(float cx, float cy, float diam, String icon, int bgc, int fgc, String act) {
      p.setStyle(Paint.Style.FILL); p.setColor(bgc);
      cv.drawCircle(cx, cy, diam / 2f, p);
      icon(icon, cx, cy, diam * 0.5f, fgc);
      if (act != null) out.zones.add(new Zone(new RectF(cx - diam / 2f, cy - diam / 2f, cx + diam / 2f, cy + diam / 2f), act));
    }

    static Bitmap dec(String b64) {
      try {
        if (b64 == null || b64.isEmpty()) return null;
        byte[] raw = Base64.decode(b64, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(raw, 0, raw.length);
      } catch (Exception e) { return null; }
    }
    void cover(float l, float t, float r, float b, String title, Bitmap bm, float rad) {
      RectF dst = new RectF(l, t, r, b);
      Path clip = new Path();
      clip.addRoundRect(dst, rad, rad, Path.Direction.CW);
      cv.save();
      cv.clipPath(clip);
      if (bm != null) {
        float br = bm.getWidth() / (float) bm.getHeight(), dr = (r - l) / (b - t);
        Rect src;
        if (br > dr) { int nw = (int) (bm.getHeight() * dr); int x = (bm.getWidth() - nw) / 2; src = new Rect(x, 0, x + nw, bm.getHeight()); }
        else { int nh = (int) (bm.getWidth() / dr); int y = (bm.getHeight() - nh) / 2; src = new Rect(0, y, bm.getWidth(), y + nh); }
        p.setStyle(Paint.Style.FILL); p.setColor(WHITE);
        cv.drawBitmap(bm, src, dst, p);
      } else {
        int i = Math.abs((title == null ? "" : title).hashCode()) % 5;
        int[] bgs = {acc, mix(acc, WHITE, 0.4f), INK, SLATE, PAPER};
        int[] fgs = {INK, INK, WHITE, WHITE, INK};
        p.setStyle(Paint.Style.FILL); p.setColor(bgs[i]);
        cv.drawRect(dst, p);
        float ts = Math.max(8 * dp, (r - l) * 0.17f);
        ArrayList<String> lines = wrap(title, ts, 1, (r - l) * 0.78f, 3);
        float y = b - 4 * dp - (lines.size() - 1) * ts * 1.15f;
        for (String ln : lines) { text(ln, l + (r - l) * 0.2f, y, ts, fgs[i], 1, 0, 0); y += ts * 1.15f; }
      }
      p.setColor(al(0xFF000000, 0.16f));
      cv.drawRect(l, t, l + Math.max(3 * dp, (r - l) * 0.08f), b, p);
      cv.restore();
    }

    float header(String title, String icon, int col) {
      float P = 8 * u, hh = Math.max(26 * dp, 17 * u), s = fs(8.8f, 13), cy = P + hh / 2f, x = P;
      if (icon != null) { icon(icon, x + s * 0.6f, cy, s * 1.25f, col); x += s * 1.6f; }
      text(title, x, cbase(cy, s, 1), s, al(col, 0.9f), 1, 0, W - x - P);
      return P + hh;
    }

    static String fmt(long ms) {
      long s = Math.max(0, ms) / 1000, h = s / 3600, m = (s % 3600) / 60, x = s % 60;
      return (h > 0 ? h + ":" + (m < 10 ? "0" : "") + m : (m < 10 ? "0" : "") + m) + ":" + (x < 10 ? "0" : "") + x;
    }
    int[] arr(String k, int n) {
      int[] a = new int[n];
      JSONArray j = d.optJSONArray(k);
      for (int i = 0; i < n; i++) a[i] = j == null ? 0 : j.optInt(i, 0);
      return a;
    }
    String dayLetter(int i) { return "SMTWTFS".substring(((d.optInt("dow", 0) - 6 + i + 14) % 7), ((d.optInt("dow", 0) - 6 + i + 14) % 7) + 1); }
    String dayName(int i) { String[] n = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}; return n[(d.optInt("dow", 0) - 6 + i + 14) % 7]; }

    /* ---------- 1. Streak ---------- */
    void streak() {
      boolean wide = W > 1.6f * H;
      u = Math.min(W, H) / 100f;
      float P = 8 * u;
      bg(acc);
      int n = d.optInt("st", 0);
      header("Streak", "fire", INK);
      int[] wp = arr("wp", 7), wa = arr("wa", 7);
      if (!wide) {
        float ls = fs(7.6f, 11);
        float ltop = stack("day streak", P, H - P, ls, al(INK, 0.72f), 0, 0, W - 2 * P);
        stack(String.valueOf(n), P, ltop - 2 * u, 40 * u, INK, 2, 0, W - 2 * P);
      } else {
        float ls = fs(7.4f, 11);
        float cellsBottom = H - P - stackHeight(ls, 0) - 2 * u;
        float ch = 17 * u, g = 3 * u, cw = (W - 2 * P - 6 * g) / 7f;
        int mx = 1;
        for (int i = 0; i < 7; i++) mx = Math.max(mx, wp[i]);
        for (int i = 0; i < 7; i++) {
          float x = P + i * (cw + g);
          float ratio = wp[i] / (float) mx;
          float lv = wp[i] > 0 ? (ratio > 0.67f ? 0.92f : ratio > 0.34f ? 0.72f : 0.48f) : (wa[i] == 1 ? 0.48f : 0f);
          rr(x, cellsBottom - ch, x + cw, cellsBottom, 5 * u, lv > 0 ? al(INK, lv) : al(INK, 0.14f));
          if (i == 6 && wa[i] != 1) rrs(x, cellsBottom - ch, x + cw, cellsBottom, 5 * u, INK, 2 * dp);
          stack(dayLetter(i), x + cw / 2f, H - P, ls, INK, 1, 1, cw + g);
        }
        float rowBottom = cellsBottom - ch - 3 * u;
        float ns = 25 * u;
        float top = stack(String.valueOf(n), P, rowBottom, ns, INK, 2, 0, 0);
        float nx = P + tw(String.valueOf(n), ns, 2) + 5 * u;
        text(wa[6] == 1 ? "day streak, today is logged" : "day streak, log today to keep it", nx, rowBottom - 3 * u, fs(7.6f, 11), al(INK, 0.72f), 0, 0, W - nx - P);
      }
      out.desc = "Streak: " + n + " days";
      out.tap = "lib";
    }
    float stackHeight(float size, int style) { face(size, style); return p.descent() - p.ascent(); }

    /* ---------- 2. Today ---------- */
    void today() {
      u = Math.min(W, H) / 100f;
      float P = 8 * u;
      bg(card);
      float top = header("Today", null, fg);
      int tp = d.optInt("tp", 0), dg = Math.max(1, d.optInt("dg", 30));
      float avail = H - P - top;
      float D = Math.min(56 * u, Math.min(avail, W - 2 * P));
      float sw = 0.11f * D, cx = W / 2f, cy = top + avail / 2f;
      ring(cx, cy, (D - sw) / 2f, sw, tile, acd(), tp / (float) dg);
      float ns = D * 0.3f;
      face(ns, 2);
      text(String.valueOf(tp), cx, cy + (-p.ascent() - p.descent()) / 2f - D * 0.04f, ns, fg, 2, 1, D * 0.7f);
      float ss = Math.max(8.5f * dp, D * 0.112f);
      text("of " + dg + " pages", cx, cy + D * 0.26f, ss, al(fg, 0.62f), 0, 1, D * 0.82f);
      out.desc = "Today: " + tp + " of " + dg + " pages";
      out.tap = "log";
    }

    /* ---------- 3. Reading now ---------- */
    void reading() {
      u = Math.min(W / 2.1f, H) / 100f;
      float P = 8 * u;
      bg(PANEL);
      float top = header("Reading now", null, WHITE);
      float bh = Math.max(36 * dp, 25 * u), gap = 4 * u;
      JSONObject b = d.optJSONObject("b");
      if (b == null || b.optString("t", "").isEmpty()) {
        boolean has = d.optInt("nb", 0) > 0;
        float s = fs(9.6f, 14);
        float cy = top + (H - P - top) / 2f;
        text(has ? "Nothing in progress" : "Your shelf is empty", P, cbase(cy - 8 * u, s, 1), s, WHITE, 1, 0, W - 2 * P);
        pill(P, cy + 2 * u, P + Math.min(W - 2 * P, 70 * u), cy + 2 * u + bh * 0.9f, "Add a book", acc, INK, false, fs(8.2f, 12), "add");
        out.desc = has ? "Nothing in progress" : "Your shelf is empty";
        out.tap = "lib";
        return;
      }
      float by = H - P - bh;
      float pw = (W - 2 * P - 2 * gap) / 3f, ps = fs(8.2f, 12);
      pill(P, by, P + pw, by + bh, "\u221210", 0, WHITE, true, ps, "undo:10");
      pill(P + pw + gap, by, P + 2 * pw + gap, by + bh, "+10 pages", acc, INK, false, ps, "pages:10");
      pill(P + 2 * (pw + gap), by, W - P, by + bh, "+25", 0, WHITE, true, ps, "pages:25");
      float availH = by - gap - top;
      float ch = Math.min(40 * u, availH), cw = ch * 20f / 30f;
      float ctop = top + (availH - ch) / 2f;
      cover(P, ctop, P + cw, ctop + ch, b.optString("t"), dec(b.optString("cov", "")), 6 * dp);
      float tx = P + cw + 5 * u, tmax = W - tx - P;
      int pc = b.optInt("pct", 0);
      float ts = fs(9.6f, 14), ms = fs(7.6f, 11), barH = Math.max(3.6f * u, 4 * dp);
      float blockH = ts * 1.2f + ms * 1.4f + barH + 4 * u;
      float y = ctop + (ch - blockH) / 2f;
      float tb = stack(b.optString("t"), tx, y + ts * 1.2f, ts, WHITE, 1, 0, tmax);
      String sub = b.optString("a") + " \u00b7 page " + b.optInt("pg") + " of " + b.optInt("tot") + " \u00b7 " + pc + "%";
      stack(sub, tx, y + ts * 1.2f + ms * 1.4f + 1 * u, ms, al(WHITE, 0.72f), 0, 0, tmax);
      float barY = y + blockH - barH;
      rr(tx, barY, tx + tmax, barY + barH, barH / 2f, al(WHITE, 0.16f));
      if (pc > 0) rr(tx, barY, tx + tmax * Math.min(100, pc) / 100f, barY + barH, barH / 2f, acc);
      out.desc = "Reading now: " + b.optString("t") + ", " + pc + " percent";
      out.tap = "lib";
    }

    /* ---------- 4. Up next ---------- */
    void next() {
      u = Math.min(W, H / 2.1f) / 100f;
      float P = 8 * u;
      int ac3 = mix(acc, card, 0.18f);
      bg(ac3);
      float top = header("Up next", null, fg);
      float bh = Math.max(36 * dp, 25 * u), gap = 3 * u, ps = fs(8.2f, 12);
      JSONArray nx = d.optJSONArray("nx");
      int n = nx == null ? 0 : nx.length();
      if (n == 0) {
        float s = fs(9.6f, 14), cy = top + (H - P - top) / 2f;
        text("Your reading list", W / 2f, cbase(cy - 12 * u, s, 1), s, fg, 1, 1, W - 2 * P);
        text("is empty", W / 2f, cbase(cy + 2 * u, s, 1), s, fg, 1, 1, W - 2 * P);
        pill(P, H - P - bh, W - P, H - P, "Add a book", INK, WHITE, false, ps, "add");
        out.desc = "Up next: your reading list is empty";
        out.tap = "lib";
        return;
      }
      int k = ((WidgetUtil.pi(ctx) % n) + n) % n;
      JSONObject[] L = new JSONObject[Math.min(3, n)];
      for (int i = 0; i < L.length; i++) L[i] = nx.optJSONObject((k + i) % n);
      JSONObject b = L[0];
      float startTop = H - P - bh, btnTop = startTop;
      pill(P, startTop, W - P, startTop + bh, "Start reading", fg, dk ? INK : WHITE, false, ps, "start:" + b.optString("id"));
      if (n > 1) {
        btnTop = startTop - gap - bh;
        pill(P, btnTop, W - P, btnTop + bh, "Shuffle", 0, fg, true, ps, "shuffle");
      }
      float midTop = top + 2 * u, midBottom = btnTop - 3 * u;
      float titleS = fs(9.4f, 13), metaS = fs(7.6f, 11);
      float metaH = metaS * 1.4f, titleH = titleS * 2.3f;
      float fanH = Math.max(24 * u, Math.min(96 * u, midBottom - midTop - titleH - metaH - 4 * u));
      float k2 = Math.min(Math.min(1.25f, (W - 2 * P) / (74 * u)), fanH / (64 * u));
      float cx = W / 2f, fb = midTop + fanH;
      float bw = 36 * u * k2, bhh = 54 * u * k2;
      if (L.length > 2) drawBook(L[2], cx - 17 * u * k2, fb, bw * 0.9f, bhh * 0.9f, -9f);
      if (L.length > 1) drawBook(L[1], cx + 17 * u * k2, fb, bw * 0.9f, bhh * 0.9f, 9f);
      drawBook(b, cx, fb - 4 * u * k2, bw * 1.1f, bhh * 1.1f, 0f);
      float ty = fb + 3 * u;
      ArrayList<String> lines = wrap(b.optString("t"), titleS, 1, W - 2 * P, 2);
      for (String ln : lines) { text(ln, cx, ty + titleS * 0.95f, titleS, fg, 1, 1, 0); ty += titleS * 1.15f; }
      text(b.optString("a") + " \u00b7 " + b.optInt("p") + " pages", cx, ty + metaS * 1.05f, metaS, al(fg, 0.72f), 0, 1, W - 2 * P);
      out.desc = "Up next: " + b.optString("t");
      out.tap = "lib";
    }
    void drawBook(JSONObject b, float cx, float bottom, float w, float h, float deg) {
      cv.save();
      cv.rotate(deg, cx, bottom);
      cover(cx - w / 2f, bottom - h, cx + w / 2f, bottom, b.optString("t"), dec(b.optString("cov", "")), 5 * u);
      cv.restore();
    }

    /* ---------- 5. Focus (timer and stopwatch) ---------- */
    void focus() {
      String z = W > 1.6f * H ? "w" : (W >= 230 * dp && H >= 230 * dp) ? "l" : "s";
      u = z.equals("l") ? Math.min(W, H) / 210f : Math.min(W, H) / 100f;
      float P = 8 * u;
      int bgc = mix(acc, WHITE, 0.4f);
      bg(bgc);
      JSONObject t = d.optJSONObject("tm");
      boolean has = t != null && t.optBoolean("has", false);
      boolean run = has && t.optBoolean("run", false);
      long acc0 = t == null ? 0 : t.optLong("acc", 0), t0 = t == null ? 0 : t.optLong("t0", 0);
      long el = acc0 + (run && t0 > 0 ? Math.max(0, System.currentTimeMillis() - t0) : 0);
      int g = t == null ? 25 : t.optInt("g", 25);
      boolean sw = g == 0;
      int G = sw ? (t == null ? 25 : Math.max(1, t.optInt("gl", 25))) : g;
      long goalMs = G * 60000L, rem = Math.max(0, goalMs - el);
      boolean done = !sw && el >= goalMs;
      float prog = sw ? (el % 60000L) / 60000f : Math.min(1f, el / (float) goalMs);
      String disp = sw ? fmt(el) : fmt(((rem + 999) / 1000) * 1000);
      String status = sw ? (run ? "Running" : el > 0 ? "Paused" : "Ready") : (done ? "Goal reached" : run ? "Reading\u2026" : el > 0 ? "Paused" : G + " min");
      boolean live = run && !done;
      if (live) { out.chron = true; out.down = !sw; out.ms = sw ? el : rem; }
      float bh = Math.max(36 * dp, 25 * u), bs = fs(8.2f, 12), hh = Math.max(26 * dp, 17 * u);
      String mode = sw ? (z.equals("l") ? "Stopwatch" : "Watch") : "Timer";
      String toggle = run ? "Pause" : el > 0 ? "Resume" : "Start";
      float chipW = Math.min(W * 0.5f, tw(mode, bs, 1) + 34 * dp);
      // mode chip (top left) and running dot
      float wideD = Math.min(H - 2 * P, W * 0.4f);
      float chipX = z.equals("w") ? P + wideD + 6 * u : P;
      pill(chipX, P, chipX + chipW, P + hh, mode, 0, INK, true, fs(7.8f, 11), "fmode");
      if (run) { p.setStyle(Paint.Style.FILL); p.setColor(INK); cv.drawCircle(chipX + chipW + 8 * dp, P + hh / 2f, 3.5f * dp, p); }
      out.desc = "Focus " + (sw ? "stopwatch " : "timer ") + disp + ", " + status;
      out.tap = "timer";
      int tcol = INK;
      if (z.equals("s")) {
        float rb = H - P - bh;
        float tsz = Math.min(26 * u, (W - 2 * P) / 4.4f);
        float cy = P + hh + (rb - (P + hh)) / 2f;
        setTime(live, disp, W / 2f, cy, tsz, tcol, new RectF(P, P + hh, W - P, rb));
        text(status, W / 2f, cy + tsz * 0.95f, fs(7.6f, 11), al(INK, 0.72f), 0, 1, W - 2 * P);
        if (sw) pill(P, rb, P + (W - 3 * P - bh) , rb + bh, "Reset", 0, INK, true, bs, "freset");
        else pill(P, rb, P + (W - 3 * P - bh), rb + bh, G + " min", al(INK, 0.11f), INK, false, bs, "fgoal");
        round(W - P - bh / 2f, rb + bh / 2f, bh, run ? "pause" : "play", INK, acc, "ftoggle");
      } else if (z.equals("w")) {
        float D = wideD;
        float cx = P + D / 2f, cy = H / 2f;
        float swd = 0.11f * D;
        ring(cx, cy, (D - swd) / 2f, swd, al(INK, 0.13f), INK, prog);
        float tsz = D * 0.2f;
        setTime(live, disp, cx, cy - D * 0.04f, tsz, tcol, new RectF(cx - D * 0.36f, cy - D * 0.2f, cx + D * 0.36f, cy + D * 0.12f));
        text(status, cx, cy + D * 0.2f, Math.max(10 * dp, D * 0.075f), al(INK, 0.72f), 0, 1, D * 0.7f);
        out.zones.add(new Zone(new RectF(P, P, P + D, H - P), "timer"));
        float rx = P + D + 6 * u, rr2 = W - P, by = H - P - bh;
        if (sw) {
          float half = (rr2 - rx - 4 * u) / 2f;
          pill(rx, by, rx + half, by + bh, "Reset", 0, INK, true, bs, "freset");
          pill(rx + half + 4 * u, by, rr2, by + bh, toggle, INK, acc, false, bs, "ftoggle");
        } else {
          float pw = (rr2 - rx - 2 * 3 * u) / 3f, py = P + hh + (by - (P + hh) - bh) / 2f;
          int[] pr = {15, 25, 45};
          for (int i = 0; i < 3; i++) pill(rx + i * (pw + 3 * u), py, rx + i * (pw + 3 * u) + pw, py + bh, String.valueOf(pr[i]), pr[i] == G ? INK : al(INK, 0.11f), pr[i] == G ? acc : INK, false, bs, "fpreset:" + pr[i]);
          float half = (rr2 - rx - 4 * u) / 2f;
          pill(rx, by, rx + half, by + bh, "Reset", 0, INK, true, bs, "freset");
          pill(rx + half + 4 * u, by, rr2, by + bh, toggle, INK, acc, false, bs, "ftoggle");
        }
      } else {
        float by = H - P - bh, py = by - 4 * u - bh;
        float topArea = P + hh, botArea = sw ? by - 4 * u : py - 4 * u;
        float D = Math.min(W - 2 * P, botArea - topArea);
        float cx = W / 2f, cy = topArea + (botArea - topArea) / 2f;
        float swd = 0.11f * D;
        ring(cx, cy, (D - swd) / 2f, swd, al(INK, 0.13f), INK, prog);
        float tsz = D * 0.2f;
        setTime(live, disp, cx, cy - D * 0.04f, tsz, tcol, new RectF(cx - D * 0.36f, cy - D * 0.2f, cx + D * 0.36f, cy + D * 0.12f));
        text(status, cx, cy + D * 0.2f, Math.max(10 * dp, D * 0.075f), al(INK, 0.72f), 0, 1, D * 0.7f);
        out.zones.add(new Zone(new RectF(cx - D / 2f, cy - D / 2f, cx + D / 2f, cy + D / 2f), "timer"));
        if (!sw) {
          float pw = (W - 2 * P - 2 * 4 * u) / 3f;
          int[] pr = {15, 25, 45};
          for (int i = 0; i < 3; i++) pill(P + i * (pw + 4 * u), py, P + i * (pw + 4 * u) + pw, py + bh, pr[i] + " min", pr[i] == G ? INK : al(INK, 0.11f), pr[i] == G ? acc : INK, false, bs, "fpreset:" + pr[i]);
        }
        boolean canLog = has && !run && el >= 1000;
        int cols = canLog ? 3 : 2;
        float pw = (W - 2 * P - (cols - 1) * 4 * u) / cols;
        int ci = 0;
        pill(P, by, P + pw, by + bh, "Reset", 0, INK, true, bs, "freset"); ci++;
        pill(P + ci * (pw + 4 * u), by, P + ci * (pw + 4 * u) + pw, by + bh, toggle, INK, acc, false, bs, "ftoggle"); ci++;
        if (canLog) pill(P + ci * (pw + 4 * u), by, W - P, by + bh, "Log", al(INK, 0.11f), INK, false, bs, "flog");
      }
    }
    /* Shows the time as a live Chronometer when running, or as drawn text otherwise. */
    void setTime(boolean live, String disp, float cx, float cy, float size, int col, RectF box) {
      if (live) {
        out.chronBox = new RectF(box);
        out.chronPx = size;
        out.chronColor = col;
        out.zones.add(new Zone(new RectF(box), "timer"));
      } else {
        text(disp, cx, cbase(cy, size, 2), size, col, 2, 1, box.width());
      }
    }

    /* ---------- 6. Year goal ---------- */
    void year() {
      String z = W > 1.6f * H ? "w" : (W >= 230 * dp && H >= 230 * dp) ? "l" : "s";
      u = z.equals("l") ? Math.min(W, H) / 210f : Math.min(W, H) / 100f;
      float P = 8 * u;
      bg(PANEL);
      JSONObject y = d.optJSONObject("y");
      int goal = y == null ? 30 : Math.max(1, y.optInt("goal", 30)), done = y == null ? 0 : y.optInt("n", 0), ex = y == null ? 0 : y.optInt("ex", 0);
      String tag = y == null ? "" : y.optString("txt", "");
      int yr = d.optInt("yr", Calendar.getInstance().get(Calendar.YEAR));
      float top = header(yr + " goal", "flag", WHITE);
      float bottom = H - P;
      if (z.equals("l")) {
        // months bars at the bottom
        int[] bm = new int[12];
        JSONArray ja = y == null ? null : y.optJSONArray("bm");
        int mx = 1;
        for (int i = 0; i < 12; i++) { bm[i] = ja == null ? 0 : ja.optInt(i, 0); mx = Math.max(mx, bm[i]); }
        int cm = d.optInt("mn", 0);
        float lh = fs(7.4f, 11);
        float letterTop = H - P - stackHeight(lh, 0);
        float bw = (W - 2 * P) / 12f, barMaxH = 44 * u;
        for (int i = 0; i < 12; i++) {
          float bx = P + i * bw + bw * 0.2f;
          float v = i > cm ? 0 : bm[i];
          float bhh = Math.max(3 * dp, v / (float) mx * barMaxH);
          rr(bx, letterTop - 2 * u - bhh, bx + bw * 0.6f, letterTop - 2 * u, 3 * dp, i == cm ? acc : al(WHITE, 0.3f));
          stack("JFMAMJJASOND".substring(i, i + 1), P + i * bw + bw / 2f, H - P, lh, i == cm ? WHITE : al(WHITE, 0.7f), i == cm ? 1 : 0, 1, bw);
        }
      }
      // numbers row
      float ns = z.equals("s") ? 26 * u : z.equals("w") ? 24 * u : 30 * u;
      float rowY = top + 2 * u;
      float ntop = rowY;
      face(ns, 2);
      float nb = ntop - p.ascent();
      text(String.valueOf(done), P, nb, ns, WHITE, 2, 0, 0);
      float nx = P + tw(String.valueOf(done), ns, 2) + 4 * u;
      text(z.equals("s") ? "of " + goal : "of " + goal + " books", nx, nb, fs(7.6f, 11), al(WHITE, 0.72f), 0, 0, W - nx - P);
      float rowBottom = nb + p.descent();
      if (!z.equals("s") && !tag.isEmpty()) {
        float tsz = fs(7.8f, 11), tww = tw(tag, tsz, 1) + 16 * dp;
        float th = tsz * 1.7f, tx = W - P - tww, tyy = rowY + (ns * 0.9f - th) / 2f;
        rr(tx, tyy, tx + tww, tyy + th, th / 2f, acc);
        text(tag, tx + tww / 2f, cbase(tyy + th / 2f, tsz, 1), tsz, INK, 1, 1, tww);
      }
      // rack of spines
      float rh = z.equals("s") ? 17 * u : z.equals("w") ? 22 * u : 42 * u;
      float rackTop, rackBottom;
      if (z.equals("l")) { rackTop = rowBottom + 5 * u; rackBottom = rackTop + rh; }
      else { rackBottom = H - P - (z.equals("s") ? 0 : 6 * u); rackTop = rackBottom - rh; }
      int N = Math.min(goal, 40);
      int F = done >= goal ? N : Math.min(N, Math.max(done > 0 ? 1 : 0, Math.round(done / (float) goal * N)));
      float gap = 0.7f * u, sw2 = (W - 2 * P - (N - 1) * gap) / N;
      for (int i = 0; i < N; i++) {
        float hh2 = rh * (55 + (i * 37) % 46) / 100f, sx = P + i * (sw2 + gap);
        rr(sx, rackBottom - hh2, sx + sw2, rackBottom, Math.min(2 * dp, sw2 / 2f), i < F ? acc : al(WHITE, 0.2f));
      }
      if (!z.equals("s")) {
        float mxp = P + (W - 2 * P) * Math.min(98f, ex / (float) goal * 100f) / 100f;
        Path tri = new Path();
        tri.moveTo(mxp, rackBottom + 1 * u); tri.lineTo(mxp - 2.6f * u, rackBottom + 5 * u); tri.lineTo(mxp + 2.6f * u, rackBottom + 5 * u); tri.close();
        p.setStyle(Paint.Style.FILL); p.setColor(WHITE); cv.drawPath(tri, p);
      }
      if (z.equals("l")) {
        String line = (done > 0 && d.optInt("doy", 0) >= 30 && y != null) ? "On track for " + y.optInt("proj", 0) + " books by December" : goal + " book goal for " + yr;
        text(line, P, rackBottom + 5 * u + fs(7.6f, 11) * 1.4f + 2 * u, fs(7.6f, 11), al(WHITE, 0.72f), 0, 0, W - 2 * P);
      }
      out.desc = yr + " goal: " + done + " of " + goal + " books" + (tag.isEmpty() ? "" : ", " + tag);
      out.tap = "year";
    }

    /* ---------- 7. Week ---------- */
    void week() {
      boolean large = W >= 230 * dp && H >= 230 * dp && W <= 1.6f * H;
      u = large ? Math.min(W, H) / 210f : Math.min(W / 2.1f, H) / 100f;
      float P = 8 * u;
      bg(card);
      float top = header("Week", null, fg);
      int[] wp = arr("wp", 7);
      int total = 0, best = 0, bi = -1, mx = 1;
      for (int i = 0; i < 7; i++) { total += wp[i]; mx = Math.max(mx, wp[i]); if (wp[i] > best) { best = wp[i]; bi = i; } }
      String read = dayName(6) + " \u00b7 " + wp[6] + " pages";
      float rs = fs(8.8f, 12);
      text(read, W - P, cbase(P + Math.max(26 * dp, 17 * u) / 2f, rs, 1), rs, al(fg, 0.88f), 1, 2, W * 0.5f);
      float lh = fs(7.4f, 11);
      float bottom = H - P;
      float tilesH = 0;
      if (large) {
        tilesH = 34 * u;
        float tw3 = (W - 2 * P - 2 * 4 * u) / 3f, ty = bottom - tilesH;
        String[] vals = {String.valueOf(total), String.valueOf(Math.round(total / 7f)), bi < 0 ? "\u2013" : dayName(bi)};
        String[] labs = {"pages", "per day", "best day"};
        for (int i = 0; i < 3; i++) {
          float tx = P + i * (tw3 + 4 * u);
          rr(tx, ty, tx + tw3, ty + tilesH, 8 * u, tile);
          text(vals[i], tx + 5 * u, cbase(ty + tilesH * 0.38f, 11 * u, 1), 11 * u, fg, 1, 0, tw3 - 8 * u);
          text(labs[i], tx + 5 * u, cbase(ty + tilesH * 0.76f, fs(7.4f, 10), 0), fs(7.4f, 10), al(fg, 0.62f), 0, 0, tw3 - 8 * u);
        }
        bottom = ty - 4 * u;
      }
      float letterH = stackHeight(lh, 0);
      float baseY = bottom - letterH - 3 * u, maxH = baseY - (top + 6 * u);
      float bw = (W - 2 * P) / 7f;
      for (int i = 0; i < 7; i++) {
        float h = Math.max(3 * dp, wp[i] / (float) mx * maxH);
        float bx = P + i * bw + (bw - Math.min(13 * u, bw * 0.62f)) / 2f, bx2 = bx + Math.min(13 * u, bw * 0.62f);
        rr(bx, baseY - h, bx2, baseY, 5 * u, i == 6 ? acd() : al(acd(), 0.35f));
        stack(dayLetter(i), P + i * bw + bw / 2f, bottom, lh, i == 6 ? fg : al(fg, 0.62f), i == 6 ? 1 : 0, 1, bw);
      }
      out.desc = "Week: " + total + " pages in the last 7 days";
      out.tap = "stats";
    }

    /* ---------- 8. Quick add ---------- */
    void add() {
      u = Math.min(W, H) / 100f;
      float P = 8 * u;
      bg(acc);
      float D = Math.max(40 * dp, 30 * u);
      round(P + D / 2f, P + D / 2f + 2 * u, D, "plus", INK, acc, null);
      float s = fs(11.5f, 15);
      float y = H - P;
      face(s, 2);
      float lh = s * 1.1f;
      text("book", P, y - p.descent(), s, INK, 2, 0, W - 2 * P);
      text("Add a", P, y - p.descent() - lh, s, INK, 2, 0, W - 2 * P);
      out.desc = "Add a book";
      out.tap = "add";
    }
  }

}

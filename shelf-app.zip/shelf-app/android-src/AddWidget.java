package __PACKAGE__;

public class AddWidget extends ShelfWidget {
  @Override
  String kind() { return "add"; }
}

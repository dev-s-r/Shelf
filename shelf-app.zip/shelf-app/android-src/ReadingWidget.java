package __PACKAGE__;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

import org.json.JSONObject;

/* "Reading now": cover, progress, Log pages and Timer shortcuts. Always lavender. */
public class ReadingWidget extends AppWidgetProvider {

  @Override
  public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    for (int id : ids) m.updateAppWidget(id, build(c));
  }

  static RemoteViews build(Context c) {
    JSONObject d = WidgetUtil.data(c);
    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_reading);
    String title = d.optString("t", "");
    v.setInt(R.id.wbg, "setColorFilter", 0xFFBCA9FB);
    if (title.isEmpty()) {
      v.setTextViewText(R.id.wtitle, "Nothing in progress");
      v.setTextViewText(R.id.wauthor, "Open Shelf to add a book");
      v.setTextViewText(R.id.wpages, "");
      v.setProgressBar(R.id.wprog, 100, 0, false);
    } else {
      v.setTextViewText(R.id.wtitle, title);
      v.setTextViewText(R.id.wauthor, d.optString("a", ""));
      int pct = Math.max(0, Math.min(100, d.optInt("pct", 0)));
      v.setProgressBar(R.id.wprog, 100, pct, false);
      v.setTextViewText(R.id.wpages, "p. " + d.optInt("pg", 0) + " of " + d.optInt("tot", 0) + "  \u00b7  " + pct + "%");
    }
    Bitmap cv = WidgetUtil.cover(d, 24f);
    if (cv != null) v.setImageViewBitmap(R.id.wcover, cv);
    else v.setImageViewResource(R.id.wcover, R.drawable.w_cover_ph);
    v.setOnClickPendingIntent(R.id.wroot, WidgetUtil.open(c, "lib", 1));
    v.setOnClickPendingIntent(R.id.wlog, WidgetUtil.open(c, "log", 2));
    v.setOnClickPendingIntent(R.id.wtimer, WidgetUtil.open(c, "timer", 3));
    return v;
  }
}

package __PACKAGE__;

public class ReadingWidget extends ShelfWidget {
  @Override
  String kind() { return "reading"; }
}

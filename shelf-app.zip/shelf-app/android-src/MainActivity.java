package __PACKAGE__;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends BridgeActivity {

  private String pendingAction = "";

  private void grabAction(Intent i) {
    if (i != null && i.hasExtra("shelf_action")) pendingAction = i.getStringExtra("shelf_action");
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    grabAction(intent);
  }

  private static class SaveJob {
    OutputStream os;
    Uri uri;
  }

  private final Map<String, SaveJob> jobs = new HashMap<>();

  @Override
  public void onCreate(Bundle savedInstanceState) {
    otaBoot();
    super.onCreate(savedInstanceState);
    grabAction(getIntent());
    otaApply();

    // Edge-to-edge on every Android version; the content is padded by the system bars here.
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    final View root = findViewById(android.R.id.content);
    ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
      Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
      Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
      v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
      return WindowInsetsCompat.CONSUMED;
    });
    ViewCompat.requestApplyInsets(root);
    getWindow().getDecorView().setBackgroundColor(Color.parseColor("#0D111B"));

    getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "AndroidBridge");

    // Back gesture: let the web app close its own dialogs first (window.__appBack), otherwise leave the app.
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        getBridge().getWebView().evaluateJavascript(
            "window.__nativeBack ? window.__nativeBack() : false",
            value -> { if (!"true".equals(value)) finish(); });
      }
    });
  }

  private void toast(final String msg) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
  }

  /* ---------- quick web updates (own downloader, no third-party plugin) ---------- */
  private static final String OTA_PREFS = "opener_ota";
  private static final String CAP_PREFS = "CapWebViewSettings";
  private static final String CAP_PATH = "serverBasePath";

  private File otaRoot() { return new File(getFilesDir(), "ota"); }

  private void otaClear() {
    getSharedPreferences(CAP_PREFS, MODE_PRIVATE).edit().remove(CAP_PATH).commit();
    getSharedPreferences(OTA_PREFS, MODE_PRIVATE).edit().putBoolean("pending", false).remove("name").commit();
    OtaUpdater.prune(otaRoot(), "\u0000");
  }

  // Runs before the web view starts: a new app version or an update that never reported success goes back to the built-in files.
  private void otaBoot() {
    try {
      SharedPreferences p = getSharedPreferences(OTA_PREFS, MODE_PRIVATE);
      PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
      long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
      if (p.getLong("apk", -1) != code) {
        otaClear();
        p.edit().putLong("apk", code).commit();
      } else if (p.getBoolean("pending", false)) {
        otaClear();
      }
    } catch (Exception e) {
      otaClear();
    }
  }

  // After the web view exists: make sure the saved update folder is the one being shown.
  private void otaApply() {
    try {
      String name = getSharedPreferences(OTA_PREFS, MODE_PRIVATE).getString("name", null);
      if (name == null) return;
      File dir = new File(otaRoot(), name);
      if (!new File(dir, "index.html").isFile()) { otaClear(); return; }
      String now = null;
      try { now = (String) getBridge().getClass().getMethod("getServerBasePath").invoke(getBridge()); } catch (Exception ignored) { /* reload below */ }
      if (now == null || !now.equals(dir.getAbsolutePath())) getBridge().setServerBasePath(dir.getAbsolutePath());
    } catch (Exception e) { /* keep the built-in files */ }
  }

  /* ---------- in-app updates ---------- */
  private static final String INSTALL_ACTION = "com.opener.app.INSTALL_RESULT";
  private BroadcastReceiver installReceiver;

  private void updJs(String call) {
    runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
      "window." + call.split("\\(")[0] + " && window." + call, null));
  }

  private void updResult(String status, String msg) {
    updJs("__updResult(" + JSONObject.quote(status) + "," + JSONObject.quote(msg == null ? "" : msg) + ")");
  }

  private boolean sameKey(File apk) {
    try {
      if (Build.VERSION.SDK_INT < 28) return true;
      PackageManager pm = getPackageManager();
      PackageInfo mine = pm.getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
      PackageInfo theirs = pm.getPackageArchiveInfo(apk.getAbsolutePath(), PackageManager.GET_SIGNING_CERTIFICATES);
      if (theirs == null || theirs.signingInfo == null || mine.signingInfo == null) return true;
      Signature[] a = mine.signingInfo.getApkContentsSigners();
      Signature[] b = theirs.signingInfo.getApkContentsSigners();
      if (a == null || b == null || a.length == 0 || b.length == 0) return true;
      return a[0].equals(b[0]);
    } catch (Exception e) {
      return true;
    }
  }

  private void registerInstallReceiver() {
    if (installReceiver != null) return;
    installReceiver = new BroadcastReceiver() {
      @Override
      public void onReceive(Context c, Intent i) {
        int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
          Intent conf = i.getParcelableExtra(Intent.EXTRA_INTENT);
          if (conf != null) {
            conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(conf);
          }
          updResult("confirm", "");
        } else if (st == PackageInstaller.STATUS_SUCCESS) {
          updResult("success", "");
        } else {
          String m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
          updResult("error", m == null ? "The update could not be installed." : m);
        }
      }
    };
    IntentFilter f = new IntentFilter(INSTALL_ACTION);
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_NOT_EXPORTED);
    else registerReceiver(installReceiver, f);
  }

  private void downloadAndInstall(String urlStr) {
    try {
      File dir = new File(getCacheDir(), "update");
      dir.mkdirs();
      File apk = new File(dir, "Opener.apk");
      java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(urlStr).openConnection();
      c.setConnectTimeout(20000);
      c.setReadTimeout(30000);
      c.setInstanceFollowRedirects(true);
      int code = c.getResponseCode();
      if (code / 100 != 2) throw new Exception("Download failed (" + code + ")");
      long total = c.getContentLengthLong();
      try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(apk)) {
        byte[] buf = new byte[65536];
        long done = 0;
        int n, last = -1;
        while ((n = in.read(buf)) > 0) {
          out.write(buf, 0, n);
          done += n;
          if (total > 0) {
            int p = (int) (done * 100 / total);
            if (p != last) { last = p; updJs("__updProgress(" + p + ")"); }
          }
        }
      }
      if (!sameKey(apk)) {
        updResult("error", "This update is signed with a different key, so Android will not install it over this app. It needs one reinstall. Save a backup first.");
        return;
      }
      PackageInstaller pi = getPackageManager().getPackageInstaller();
      PackageInstaller.SessionParams p = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
      p.setAppPackageName(getPackageName());
      if (Build.VERSION.SDK_INT >= 31) p.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
      int id = pi.createSession(p);
      registerInstallReceiver();
      try (PackageInstaller.Session s = pi.openSession(id)) {
        try (InputStream in = new java.io.FileInputStream(apk); OutputStream out = s.openWrite("Opener.apk", 0, apk.length())) {
          byte[] buf = new byte[65536];
          int n;
          while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
          s.fsync(out);
        }
        Intent cb = new Intent(INSTALL_ACTION).setPackage(getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
        PendingIntent pend = PendingIntent.getBroadcast(this, id, cb, flags);
        s.commit(pend.getIntentSender());
      }
    } catch (Exception e) {
      updResult("error", e.getMessage() == null ? "The update failed." : e.getMessage());
    }
  }

  private void scanJs(String status, String value) {
    final String v = value == null ? "" : value;
    runOnUiThread(() -> getBridge().getWebView().evaluateJavascript(
        "window.__scanResult && window.__scanResult(" + JSONObject.quote(status) + "," + JSONObject.quote(v) + ")", null));
  }

  private class NativeBridge {
    /* Home-screen widgets: the web app sends a small JSON snapshot after every change. */
    @JavascriptInterface
    public void setWidgetData(String json) {
      try {
        WidgetUtil.save(MainActivity.this, json);
        WidgetUtil.refreshAll(MainActivity.this);
      } catch (Exception e) { /* widgets are optional */ }
    }

    /* A widget tap leaves a one-shot instruction ("lib", "log", "timer"). */
    @JavascriptInterface
    public String takeAction() {
      String a = pendingAction == null ? "" : pendingAction;
      pendingAction = "";
      return a;
    }

    /* Daily reminder: saved in preferences, fired by ReminderReceiver. */
    @JavascriptInterface
    public void setReminder(boolean on, int h, int m, boolean ask) {
      getSharedPreferences("shelf_rem", MODE_PRIVATE).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply();
      if (on && ask && Build.VERSION.SDK_INT >= 33
          && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
        runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 4411));
      }
      ReminderReceiver.schedule(MainActivity.this);
    }

    /* The web app tells us the last day with a reading log, so today's reminder can be skipped. */
    @JavascriptInterface
    public void markLogged(String day) {
      getSharedPreferences("shelf_rem", MODE_PRIVATE).edit().putString("last", day == null ? "" : day).apply();
    }

    /* Barcode scan: Google's code scanner screen (no camera permission needed). Result goes to window.__scanResult(status, value). */
    @JavascriptInterface
    public void scanBarcode() {
      runOnUiThread(() -> {
        try {
          GmsBarcodeScannerOptions opts = new GmsBarcodeScannerOptions.Builder()
              .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
              .enableAutoZoom()
              .build();
          GmsBarcodeScanning.getClient(MainActivity.this, opts).startScan()
              .addOnSuccessListener(b -> scanJs("ok", b.getRawValue()))
              .addOnCanceledListener(() -> scanJs("cancel", ""))
              .addOnFailureListener(e -> scanJs("error", e.getMessage()));
        } catch (Exception e) {
          scanJs("error", e.getMessage());
        }
      });
    }

    @JavascriptInterface
    public void otaInstall(final String url, final String name) {
      new Thread(() -> {
        try {
          final File dir = OtaUpdater.downloadAndExtract(url, otaRoot(), "b" + name.replaceAll("[^0-9A-Za-z]", ""),
            p -> updJs("__updProgress(" + p + ")"));
          getSharedPreferences(OTA_PREFS, MODE_PRIVATE).edit().putString("name", dir.getName()).putBoolean("pending", true).commit();
          getSharedPreferences(CAP_PREFS, MODE_PRIVATE).edit().putString(CAP_PATH, dir.getAbsolutePath()).commit();
          runOnUiThread(() -> getBridge().setServerBasePath(dir.getAbsolutePath()));
        } catch (Exception e) {
          updResult("error", e.getMessage() == null ? "The update could not be downloaded." : e.getMessage());
        }
      }).start();
    }

    @JavascriptInterface
    public void otaReady() {
      SharedPreferences sp = getSharedPreferences(OTA_PREFS, MODE_PRIVATE);
      if (!sp.getBoolean("pending", false)) return;
      sp.edit().putBoolean("pending", false).commit();
      String keep = sp.getString("name", null);
      if (keep != null) OtaUpdater.prune(otaRoot(), keep);
    }

    @JavascriptInterface
    public String apkInfo() {
      try {
        PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
        long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        boolean can = Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
        return new JSONObject().put("versionCode", code).put("versionName", pi.versionName).put("canInstall", can).toString();
      } catch (Exception e) {
        return "{}";
      }
    }

    @JavascriptInterface
    public void openInstallPermission() {
      try {
        Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
      } catch (Exception e) { /* ignore */ }
    }

    @JavascriptInterface
    public void installApk(final String url) {
      new Thread(() -> downloadAndInstall(url)).start();
    }

    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64) {
      boolean ok = write(name, mime, base64);
      toast(ok ? "Saved to Downloads: " + name : "Couldn't save the file");
      return ok;
    }

    @JavascriptInterface
    public boolean saveFileQuiet(String name, String mime, String base64) {
      return write(name, mime, base64);
    }

    // name may contain folders ("archive/sub/file.txt"); they are created inside Downloads.
    private boolean write(String name, String mime, String base64) {
      SaveJob job = null;
      try {
        job = openJob(name, mime);
        job.os.write(Base64.decode(base64, Base64.DEFAULT));
        finishJob(job);
        return true;
      } catch (Exception e) {
        abortJob(job);
        return false;
      }
    }

    // Large files are written in pieces so they never sit in memory as one big string.
    @JavascriptInterface
    public String saveBegin(String name, String mime) {
      try {
        SaveJob job = openJob(name, mime);
        String id = "j" + System.nanoTime();
        synchronized (jobs) { jobs.put(id, job); }
        return id;
      } catch (Exception e) {
        return "";
      }
    }

    @JavascriptInterface
    public boolean saveChunk(String id, String base64) {
      SaveJob job;
      synchronized (jobs) { job = jobs.get(id); }
      if (job == null) return false;
      try {
        job.os.write(Base64.decode(base64, Base64.DEFAULT));
        return true;
      } catch (Exception e) {
        synchronized (jobs) { jobs.remove(id); }
        abortJob(job);
        return false;
      }
    }

    @JavascriptInterface
    public boolean saveEnd(String id, boolean announce) {
      SaveJob job;
      synchronized (jobs) { job = jobs.remove(id); }
      if (job == null) return false;
      try {
        finishJob(job);
        if (announce) toast("Saved to Downloads");
        return true;
      } catch (Exception e) {
        abortJob(job);
        return false;
      }
    }

    private SaveJob openJob(String name, String mime) throws Exception {
      StringBuilder clean = new StringBuilder();
      for (String part : name.replace('\\', '/').split("/")) {
        if (part.isEmpty() || part.equals(".") || part.equals("..")) continue;
        if (clean.length() > 0) clean.append('/');
        clean.append(part);
      }
      String path = clean.toString();
      if (path.isEmpty()) path = "file";
      int slash = path.lastIndexOf('/');
      String dir = slash < 0 ? "" : path.substring(0, slash);
      String base = slash < 0 ? path : path.substring(slash + 1);
      String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
      SaveJob job = new SaveJob();
      if (Build.VERSION.SDK_INT >= 29) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, base);
        v.put(MediaStore.Downloads.MIME_TYPE, type);
        v.put(MediaStore.Downloads.RELATIVE_PATH, dir.isEmpty() ? Environment.DIRECTORY_DOWNLOADS : Environment.DIRECTORY_DOWNLOADS + "/" + dir);
        v.put(MediaStore.Downloads.IS_PENDING, 1);
        job.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (job.uri == null) throw new Exception("insert failed");
        job.os = getContentResolver().openOutputStream(job.uri);
      } else {
        File target = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), path);
        File parent = target.getParentFile();
        if (parent != null) parent.mkdirs();
        job.os = new FileOutputStream(target);
      }
      return job;
    }

    private void finishJob(SaveJob job) throws Exception {
      job.os.close();
      if (job.uri != null) {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(job.uri, v, null, null);
      }
    }

    private void abortJob(SaveJob job) {
      if (job == null) return;
      try { if (job.os != null) job.os.close(); } catch (Exception ignored) { }
      try { if (job.uri != null) getContentResolver().delete(job.uri, null, null); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void setChrome(final String hex, final boolean dark) {
      runOnUiThread(() -> {
        try {
          getWindow().getDecorView().setBackgroundColor(Color.parseColor(hex));
          WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
          c.setAppearanceLightStatusBars(!dark);
          c.setAppearanceLightNavigationBars(!dark);
        } catch (Exception ignored) { }
      });
    }
  }
}

package __PACKAGE__;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/* Daily reading reminder: one alarm per day, skipped when today's reading is already logged. */
public class ReminderReceiver extends BroadcastReceiver {
  static final String ACT = "__PACKAGE__.REMIND";
  static final String CH = "shelf_reminder";
  static final String PREFS = "shelf_rem";

  @Override
  public void onReceive(Context c, Intent i) {
    try {
      String a = i == null ? null : i.getAction();
      SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
      if (ACT.equals(a) && p.getBoolean("on", false)) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (!today.equals(p.getString("last", ""))) notifyNow(c);
      }
      schedule(c);
    } catch (Exception e) { /* never crash from a background broadcast */ }
  }

  private static void notifyNow(Context c) {
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm == null) return;
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(new NotificationChannel(CH, "Reading reminder", NotificationManager.IMPORTANCE_DEFAULT));
    }
    Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
    PendingIntent pi = open == null ? null
        : PendingIntent.getActivity(c, 7002, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    int icon = c.getResources().getIdentifier("ic_stat_shelf", "drawable", c.getPackageName());
    if (icon == 0) icon = android.R.drawable.ic_dialog_info;
    NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH)
        .setSmallIcon(icon)
        .setContentTitle("Time to read")
        .setContentText("A few pages today keep your streak going.")
        .setAutoCancel(true);
    if (pi != null) b.setContentIntent(pi);
    nm.notify(7003, b.build());
  }

  static void schedule(Context c) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    Intent in = new Intent(c, ReminderReceiver.class).setAction(ACT);
    PendingIntent pi = PendingIntent.getBroadcast(c, 7001, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    if (!p.getBoolean("on", false)) { am.cancel(pi); return; }
    Calendar t = Calendar.getInstance();
    t.set(Calendar.HOUR_OF_DAY, p.getInt("h", 20));
    t.set(Calendar.MINUTE, p.getInt("m", 0));
    t.set(Calendar.SECOND, 0);
    t.set(Calendar.MILLISECOND, 0);
    if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_YEAR, 1);
    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
  }
}

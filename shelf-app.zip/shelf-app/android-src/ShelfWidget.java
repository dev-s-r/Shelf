package __PACKAGE__;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

/* One painted picture plus an invisible grid of tap zones. Subclasses only say which widget they are. */
public abstract class ShelfWidget extends AppWidgetProvider {

  abstract String kind();

  @Override
  public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    for (int id : ids) m.updateAppWidget(id, build(c, m, id));
  }

  @Override
  public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
    m.updateAppWidget(id, build(c, m, id));
  }

  RemoteViews build(Context c, AppWidgetManager m, int id) {
    Bundle o = m.getAppWidgetOptions(id);
    float w = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
    float h = o == null ? 0 : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
    String k = kind();
    if (w < 60) w = (k.equals("reading") || k.equals("week")) ? 280 : 130;
    if (h < 60) h = k.equals("next") ? 280 : 130;
    float dens = c.getResources().getDisplayMetrics().density;
    WidgetArt.Out out = WidgetArt.paint(c, k, WidgetUtil.data(c), w, h, dens);

    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_canvas);
    v.setImageViewBitmap(R.id.wimg, out.bmp);
    v.setContentDescription(R.id.wimg, out.desc);
    v.setOnClickPendingIntent(R.id.wroot, WidgetUtil.open(c, out.tap));

    boolean chron = out.chron && !(out.down && Build.VERSION.SDK_INT < 24);
    if (chron) {
      float s = out.scale <= 0 ? 1f : out.scale;
      RectF b = out.chronBox;
      v.setViewVisibility(R.id.wchron, View.VISIBLE);
      long base = SystemClock.elapsedRealtime() + (out.down ? out.ms : -out.ms);
      v.setChronometer(R.id.wchron, base, null, true);
      if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.wchron, out.down);
      v.setTextColor(R.id.wchron, out.chronColor);
      v.setTextViewTextSize(R.id.wchron, TypedValue.COMPLEX_UNIT_PX, out.chronPx / s);
      v.setViewPadding(R.id.wchron, Math.round(b.left / s), Math.round(b.top / s),
          Math.round((out.bmp.getWidth() - b.right) / s), Math.round((out.bmp.getHeight() - b.bottom) / s));
    } else {
      v.setViewVisibility(R.id.wchron, View.GONE);
    }

    float gw = out.bmp.getWidth() / 12f, gh = out.bmp.getHeight() / 6f;
    for (WidgetArt.Zone z : out.zones) {
      android.app.PendingIntent pi = z.act.equals("shuffle") ? WidgetUtil.shuffle(c) : WidgetUtil.open(c, z.act);
      for (int r = 0; r < 6; r++) {
        for (int q = 0; q < 12; q++) {
          float cx = (q + 0.5f) * gw, cy = (r + 0.5f) * gh;
          if (cx >= z.r.left && cx <= z.r.right && cy >= z.r.top && cy <= z.r.bottom) {
            v.setOnClickPendingIntent(WidgetUtil.Z[r][q], pi);
          }
        }
      }
    }
    return v;
  }
}

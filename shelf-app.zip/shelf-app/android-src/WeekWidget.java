package __PACKAGE__;

public class WeekWidget extends ShelfWidget {
  @Override
  String kind() { return "week"; }
}

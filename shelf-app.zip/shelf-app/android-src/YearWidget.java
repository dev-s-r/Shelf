package __PACKAGE__;

public class YearWidget extends ShelfWidget {
  @Override
  String kind() { return "year"; }
}

package __PACKAGE__;

public class StreakWidget extends ShelfWidget {
  @Override
  String kind() { return "streak"; }
}

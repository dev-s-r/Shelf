package __PACKAGE__;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/* "Streak": day count and the last seven days. Uses your accent colour. */
public class StreakWidget extends AppWidgetProvider {

  @Override
  public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    for (int id : ids) m.updateAppWidget(id, build(c));
  }

  static RemoteViews build(Context c) {
    JSONObject d = WidgetUtil.data(c);
    RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_streak);
    v.setInt(R.id.sbg, "setColorFilter", WidgetUtil.accent(d));
    int n = d.optInt("streak", 0);
    v.setTextViewText(R.id.snum, String.valueOf(n));
    v.setTextViewText(R.id.slabel, n == 1 ? "day streak" : "day streak");
    int[] dots = {R.id.sd0, R.id.sd1, R.id.sd2, R.id.sd3, R.id.sd4, R.id.sd5, R.id.sd6};
    JSONArray wk = d.optJSONArray("wk");
    for (int i = 0; i < 7; i++) {
      boolean on = wk != null && wk.optInt(i, 0) == 1;
      v.setImageViewResource(dots[i], on ? R.drawable.w_dot_on : R.drawable.w_dot_off);
    }
    v.setOnClickPendingIntent(R.id.sroot, WidgetUtil.open(c, "lib", 4));
    return v;
  }
}

package __PACKAGE__;

public class FocusWidget extends ShelfWidget {
  @Override
  String kind() { return "focus"; }
}

package __PACKAGE__;

public class TodayWidget extends ShelfWidget {
  @Override
  String kind() { return "today"; }
}

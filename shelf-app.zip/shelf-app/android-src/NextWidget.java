package __PACKAGE__;

import android.content.Context;
import android.content.Intent;

public class NextWidget extends ShelfWidget {
  @Override
  String kind() { return "next"; }

  /* Shuffle cycles through the want-to-read books without opening the app. */
  @Override
  public void onReceive(Context c, Intent i) {
    if (i != null && WidgetUtil.ACT_SHUFFLE.equals(i.getAction())) {
      WidgetUtil.setPi(c, WidgetUtil.pi(c) + 1);
      WidgetUtil.refreshAll(c);
    } else {
      super.onReceive(c, i);
    }
  }
}

package __PACKAGE__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/* Shared helpers for the home-screen widgets: stored snapshot, tap targets, refresh. */
final class WidgetUtil {
  static final String PREFS = "shelf_widget";
  static final String ACT_SHUFFLE = "shelf.widget.SHUFFLE";

  /* 6 rows x 12 columns of invisible tap cells laid over the widget picture. */
  static final int[][] Z = {
    {R.id.z0_0, R.id.z0_1, R.id.z0_2, R.id.z0_3, R.id.z0_4, R.id.z0_5, R.id.z0_6, R.id.z0_7, R.id.z0_8, R.id.z0_9, R.id.z0_10, R.id.z0_11},
    {R.id.z1_0, R.id.z1_1, R.id.z1_2, R.id.z1_3, R.id.z1_4, R.id.z1_5, R.id.z1_6, R.id.z1_7, R.id.z1_8, R.id.z1_9, R.id.z1_10, R.id.z1_11},
    {R.id.z2_0, R.id.z2_1, R.id.z2_2, R.id.z2_3, R.id.z2_4, R.id.z2_5, R.id.z2_6, R.id.z2_7, R.id.z2_8, R.id.z2_9, R.id.z2_10, R.id.z2_11},
    {R.id.z3_0, R.id.z3_1, R.id.z3_2, R.id.z3_3, R.id.z3_4, R.id.z3_5, R.id.z3_6, R.id.z3_7, R.id.z3_8, R.id.z3_9, R.id.z3_10, R.id.z3_11},
    {R.id.z4_0, R.id.z4_1, R.id.z4_2, R.id.z4_3, R.id.z4_4, R.id.z4_5, R.id.z4_6, R.id.z4_7, R.id.z4_8, R.id.z4_9, R.id.z4_10, R.id.z4_11},
    {R.id.z5_0, R.id.z5_1, R.id.z5_2, R.id.z5_3, R.id.z5_4, R.id.z5_5, R.id.z5_6, R.id.z5_7, R.id.z5_8, R.id.z5_9, R.id.z5_10, R.id.z5_11}
  };

  static final Class<?>[] KINDS = {
    StreakWidget.class, TodayWidget.class, ReadingWidget.class, NextWidget.class,
    FocusWidget.class, YearWidget.class, WeekWidget.class, AddWidget.class
  };

  private WidgetUtil() {}

  static JSONObject data(Context c) {
    try {
      return new JSONObject(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", "{}"));
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  static void save(Context c, String json) {
    c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("json", json == null ? "{}" : json).apply();
  }

  static int pi(Context c) {
    return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("pi", 0);
  }

  static void setPi(Context c, int v) {
    c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("pi", v).apply();
  }

  /* Opens Shelf and tells the web app what to do, for example "lib", "pages:10" or "start:<id>". */
  static PendingIntent open(Context c, String action) {
    Intent i = new Intent(c, MainActivity.class);
    i.setAction("shelf.widget." + action);
    i.putExtra("shelf_action", action);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  /* Shuffle works inside the widget, without opening the app. */
  static PendingIntent shuffle(Context c) {
    Intent i = new Intent(c, NextWidget.class).setAction(ACT_SHUFFLE);
    return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static void refreshAll(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    for (Class<?> k : KINDS) {
      try {
        int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
        if (ids != null && ids.length > 0) {
          ShelfWidget w = (ShelfWidget) k.getDeclaredConstructor().newInstance();
          w.onUpdate(c, m, ids);
        }
      } catch (Exception e) { /* keep going with the other widgets */ }
    }
  }
}

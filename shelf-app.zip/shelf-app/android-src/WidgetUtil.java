package __PACKAGE__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.Base64;

import org.json.JSONObject;

/* Shared helpers for the home-screen widgets: stored snapshot, tap targets, rounded covers. */
final class WidgetUtil {
  static final String PREFS = "shelf_widget";

  private WidgetUtil() {}

  static JSONObject data(Context c) {
    try {
      return new JSONObject(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", "{}"));
    } catch (Exception e) {
      return new JSONObject();
    }
  }

  static void save(Context c, String json) {
    c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("json", json == null ? "{}" : json).apply();
  }

  /* Opens Shelf and tells the web app what to show: "lib", "log" or "timer". */
  static PendingIntent open(Context c, String action, int code) {
    Intent i = new Intent(c, MainActivity.class);
    i.setAction("shelf.widget." + action);
    i.putExtra("shelf_action", action);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static int accent(JSONObject d) {
    try {
      return Color.parseColor(d.optString("acc", "#D4F53C"));
    } catch (Exception e) {
      return Color.parseColor("#D4F53C");
    }
  }

  static Bitmap cover(JSONObject d, float radiusPx) {
    try {
      String b64 = d.optString("cov", "");
      if (b64.isEmpty()) return null;
      byte[] raw = Base64.decode(b64, Base64.DEFAULT);
      Bitmap src = BitmapFactory.decodeByteArray(raw, 0, raw.length);
      if (src == null) return null;
      Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
      Canvas cv = new Canvas(out);
      Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
      cv.drawRoundRect(new RectF(0, 0, src.getWidth(), src.getHeight()), radiusPx, radiusPx, p);
      p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
      cv.drawBitmap(src, 0, 0, p);
      return out;
    } catch (Exception e) {
      return null;
    }
  }

  static void refreshAll(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] a = m.getAppWidgetIds(new ComponentName(c, ReadingWidget.class));
    if (a != null && a.length > 0) m.updateAppWidget(a, ReadingWidget.build(c));
    int[] b = m.getAppWidgetIds(new ComponentName(c, StreakWidget.class));
    if (b != null && b.length > 0) m.updateAppWidget(b, StreakWidget.build(c));
  }
}

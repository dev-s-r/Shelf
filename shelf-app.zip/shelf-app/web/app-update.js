/* In-app updates for an Android app built by GitHub Actions.
 *  - quick update: new web files only (no install prompt, data kept)
 *  - full update: new APK (Android asks for one confirmation)
 * Hooks for your page (all optional):
 *   <button data-app-update>Check for updates</button>   -> opens the update check
 *   <span data-app-version></span>                         -> filled with "Build 12"
 *   window.AppUpdater.check(true | false), .version(), .setAuto(bool)
 */
(function () {
  'use strict';
  var REPO = 'dev-s-r/Shelf';
  var NB = window.AndroidBridge || null;
  var isApp = !!(NB && NB.apkInfo);
  var KEY_LAST = 'appUpd.last', KEY_AUTO = 'appUpd.auto';

  function ls(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }

  /* ---------- dialog ---------- */
  var css = document.createElement('style');
  css.textContent = '#appUpdScrim{position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:24px;font-family:system-ui,Roboto,sans-serif}' +
    '#appUpdScrim .box{background:#fff;color:#1b1b1f;border-radius:28px;padding:24px;max-width:420px;width:100%;box-sizing:border-box}' +
    '#appUpdScrim h3{margin:0 0 12px;font-size:22px;font-weight:500}#appUpdScrim p{margin:0 0 12px;line-height:1.45;white-space:pre-wrap}' +
    '#appUpdScrim .bar{height:6px;border-radius:3px;background:#e1e2ec;overflow:hidden;margin:0 0 12px;display:none}#appUpdScrim .bar div{height:100%;width:0;background:#0b57d0;transition:width .2s}' +
    '#appUpdScrim .acts{display:flex;justify-content:flex-end;gap:4px;flex-wrap:wrap}' +
    '#appUpdScrim button{height:44px;padding:0 16px;border:0;border-radius:22px;background:none;color:#0b57d0;font:500 15px system-ui,Roboto,sans-serif}' +
    '@media(prefers-color-scheme:dark){#appUpdScrim .box{background:#1f2024;color:#e3e2e6}#appUpdScrim .bar{background:#44474f}#appUpdScrim button{color:#a8c7fa}#appUpdScrim .bar div{background:#a8c7fa}}';
  document.head.append(css);

  var dlg = null, lastTry = null;
  function close() { if (dlg) { dlg.scrim.remove(); dlg = null; } }
  function open(title) {
    close();
    var scrim = el('div'); scrim.id = 'appUpdScrim';
    var box = el('div', 'box'), h = el('h3', null, title), msg = el('p'), bar = el('div', 'bar'), fill = el('div'), acts = el('div', 'acts');
    bar.append(fill); box.append(h, msg, bar, acts); scrim.append(box); document.body.append(scrim);
    scrim.addEventListener('click', function (ev) { if (ev.target === scrim) close(); });
    dlg = {
      scrim: scrim,
      title: function (t) { h.textContent = t; },
      say: function (t) { msg.textContent = t; },
      progress: function (p) { bar.style.display = p == null ? 'none' : 'block'; if (p != null) fill.style.width = Math.max(0, Math.min(100, p)) + '%'; },
      actions: function (list) { acts.innerHTML = ''; list.forEach(function (a) { var b = el('button', null, a[0]); b.type = 'button'; b.onclick = a[1]; acts.append(b); }); }
    };
    return dlg;
  }

  /* ---------- versions ---------- */
  async function localInfo() {
    var apk = {}, bi = {};
    try { apk = JSON.parse(NB.apkInfo()); } catch (e) { /* not in the app */ }
    try { bi = await (await fetch('build-info.json', { cache: 'no-store' })).json(); } catch (e) { /* not built by the workflow */ }
    return { apk: apk.versionCode || 0, name: apk.versionName || '', can: apk.canInstall !== false, build: bi.build || apk.versionCode || 0 };
  }
  async function latest() {
    var r = await fetch('https://api.github.com/repos/' + REPO + '/releases/latest', { headers: { Accept: 'application/vnd.github+json' } });
    if (!r.ok) throw new Error(r.status === 404 ? 'No update has been published yet.' : 'Could not reach GitHub (' + r.status + ').');
    var rel = await r.json(), meta = {};
    try { meta = JSON.parse(rel.body); } catch (e) { /* ignore */ }
    (rel.assets || []).forEach(function (a) {
      if (/\.apk$/i.test(a.name)) meta.apkUrl = a.browser_download_url;
      if (a.name === 'web-bundle.zip') meta.webUrl = a.browser_download_url;
    });
    if (!meta.build) { var m = /(\d+)/.exec(rel.tag_name || ''); meta.build = m ? +m[1] : 0; }
    return meta;
  }

  /* ---------- the two kinds of update ---------- */
  function webUpdate(m, info) {
    lastTry = { m: m, info: info };
    var d = open('Updating'); d.say('Downloading the update…'); d.progress(0); d.actions([]);
    NB.otaInstall(m.webUrl, String(m.build));   // on success the page reloads by itself
  }
  function apkUpdate(m, info) {
    lastTry = { m: m, info: info, kind: 'apk' };
    var d = open('Update the app');
    if (!info.can) {
      d.say('Android needs your permission to let this app install its own updates. Tap Allow, switch it on, then come back.');
      d.actions([['Not now', close], ['Allow', function () { NB.openInstallPermission(); }]]);
      var back = function () {
        if (document.hidden) return;
        document.removeEventListener('visibilitychange', back);
        localInfo().then(function (n) { if (dlg) { if (n.can) apkUpdate(m, n); else d.say('The permission is still off. Tap Allow to try again.'); } });
      };
      document.addEventListener('visibilitychange', back);
      return;
    }
    d.say('Downloading the new version…'); d.progress(0); d.actions([]);
    NB.installApk(m.apkUrl);
  }
  window.__updProgress = function (p) { if (dlg) dlg.progress(p); };
  window.__updResult = function (status, message) {
    if (!dlg) open('Update');
    dlg.progress(null);
    if (status === 'confirm') { dlg.say('Confirm the update in the Android window. Your data stays.'); dlg.actions([['Close', close]]); }
    else if (status === 'success') { dlg.say('Updated. Open the app again.'); dlg.actions([['Close', close]]); }
    else {
      dlg.say(message || 'The update could not be installed.');
      var acts = [['Close', close]];
      if (lastTry && lastTry.kind !== 'apk') {
        var t = lastTry;
        acts.push(['Try again', function () { webUpdate(t.m, t.info); }]);
        if (t.m.apkUrl) acts.push(['Full update', function () { apkUpdate(t.m, t.info); }]);
      }
      dlg.actions(acts);
    }
  };

  /* ---------- check ---------- */
  async function check(manual) {
    if (!isApp) { if (manual) { var n = open('Updates'); n.say('Updates work inside the installed Android app.'); n.actions([['Close', close]]); } return; }
    var info = await localInfo(), m, d = manual ? open('Check for updates') : null;
    if (d) { d.say('Checking…'); d.actions([]); }
    try { m = await latest(); } catch (e) {
      if (d) { d.say(e && e.message ? e.message : 'Could not check. Are you online?'); d.actions([['Close', close]]); }
      return;
    }
    lsSet(KEY_LAST, Date.now());
    if (!(m.build > info.build)) {
      if (d) { d.say('You have the latest version (build ' + info.build + ').'); d.actions([['Close', close]]); }
      return;
    }
    var quick = !!(NB.otaInstall && m.webUrl && info.apk >= (m.minApk || 0));
    var note = m.notes ? '\n\n' + m.notes : '';
    var dd = d || open('Update available');
    dd.title('Update available');
    if (quick) {
      dd.say('Build ' + m.build + ' is ready. This quick update keeps all your data and needs no installing.' + note);
      dd.actions([['Later', close], ['Update now', function () { webUpdate(m, info); }]]);
    } else if (m.apkUrl) {
      dd.say('Build ' + m.build + ' is ready. It changes the app itself, so Android will ask you to confirm. Your data stays.' + note);
      dd.actions([['Later', close], ['Update', function () { apkUpdate(m, info); }]]);
    } else { dd.say('A newer version exists, but it cannot be installed from here.'); dd.actions([['Close', close]]); }
  }

  /* ---------- wiring ---------- */
  window.AppUpdater = {
    check: check,
    version: localInfo,
    setAuto: function (on) { lsSet(KEY_AUTO, !!on); },
    isAuto: function () { return ls(KEY_AUTO, true); }
  };
  function wire() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-app-update]'), function (b) { b.addEventListener('click', function () { check(true); }); });
    var tags = document.querySelectorAll('[data-app-version]');
    if (tags.length && isApp) localInfo().then(function (i) { Array.prototype.forEach.call(tags, function (t) { t.textContent = 'Build ' + i.build; }); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire); else wire();

  // back gesture closes the update dialog first
  var prevBack = window.__appBack;
  window.__appBack = function () { if (dlg) { close(); return true; } return typeof prevBack === 'function' ? prevBack() : false; };

  if (isApp) {
    // tell the app this web version started fine (otherwise the next launch rolls back to the built-in files)
    if (NB.otaReady) setTimeout(function () { NB.otaReady(); }, 3000);
    // automatic check, at most every 6 hours
    if (ls(KEY_AUTO, true)) setTimeout(function () { if (Date.now() - ls(KEY_LAST, 0) > 6 * 3600 * 1000 && !dlg) check(false); }, 5000);
  }
})();
